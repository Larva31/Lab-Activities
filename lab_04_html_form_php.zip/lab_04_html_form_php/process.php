<?php
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

echo "Username: " . $username . "<br/>";
echo "Email: " . $email . "<br/>";
echo "Password: " . $password . "<br/>";
echo "Confirm Password: " . $confirm_password . "<br/>";
?>
