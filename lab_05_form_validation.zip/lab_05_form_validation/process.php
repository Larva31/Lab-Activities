<?php
//parang variable declaration
$username = $_POST['username'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

//conditional statements
if(empty($username)) {
    $error_message= "Username is required";
} elseif(empty($password)) {
    $error_message= "Password is required";
} elseif(strlen($password) < 8) {
    $error_message= "Password must be at least 8 characters long";
} elseif(empty($confirm_password)) {
    $error_message= "Confirm Password is required";
} elseif($confirm_password!== $password) {
    $error_message= "Password and confirm password not match";
} else{
    $error_message= null;
}

if(!empty($error_message)) {
    echo $error_message;
} else{
    echo "Registration form is valid.";
}
?>
