<?php include'db.php'; ?>
<?php
echo "Connected successfully.";
?>
