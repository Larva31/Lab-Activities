<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 03 Challenge - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-neutral min-h-screen w-screen flex items-center justify-center p-4 overflow-hidden">

<!-- Main Application Window -->
<div class="w-full max-w-6xl h-full max-h-[95vh] flex flex-col shadow-2xl rounded-3xl bg-base-100 overflow-hidden">

    <!-- Header Section -->
    <div class="px-8 py-5 border-b border-base-300 flex justify-between items-center bg-base-100 shrink-0">
        <div class="flex flex-col">
            <div class="flex items-center gap-3">
                <h1 class="text-2xl font-black tracking-tight">PHP Operator Dashboard</h1>
                <span class="badge badge-primary badge-sm font-bold">Lab 03</span>
            </div>
            <p class="text-sm text-base-content/60 mt-1">Real-time arithmetic and comparison evaluation</p>
        </div>
        
        <!-- Theme Controller -->
        <div class="join bg-base-200 p-1 rounded-lg">
            <input type="radio" class="join-item btn btn-sm btn-ghost" aria-label="Light"
                   onclick="document.documentElement.setAttribute('data-theme','light')" checked />
            <input type="radio" class="join-item btn btn-sm btn-ghost" aria-label="Dark"
                   onclick="document.documentElement.setAttribute('data-theme','dark')" />
            <input type="radio" class="join-item btn btn-sm btn-ghost" aria-label="Retro"
                   onclick="document.documentElement.setAttribute('data-theme','retro')" />
        </div>
    </div>

    <?php
    // Core Variables
    $a = 17;
    $b = 5;
    ?>

    <!-- Main Content Area -->
    <div class="flex-1 flex flex-col p-6 gap-6 min-h-0 bg-base-100">
        
        <!-- Top Stats Row -->
        <div class="stats stats-horizontal shadow-sm border border-base-200 w-full shrink-0">
            <div class="stat px-6 py-3">
                <div class="stat-figure text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block h-8 w-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                </div>
                <div class="stat-title text-xs font-bold uppercase tracking-wider">Variable A</div>
                <div class="stat-value text-primary"><?php echo $a; ?></div>
                <div class="stat-desc font-medium mt-1 <?php echo ($a % 2 === 0) ? 'text-info' : 'text-warning'; ?>">
                    Status: <?php echo ($a % 2 === 0) ? 'Even Number' : 'Odd Number'; ?>
                </div>
            </div>
            
            <div class="stat px-6 py-3 border-l border-base-200">
                <div class="stat-figure text-secondary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block h-8 w-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                </div>
                <div class="stat-title text-xs font-bold uppercase tracking-wider">Variable B</div>
                <div class="stat-value text-secondary"><?php echo $b; ?></div>
                <div class="stat-desc font-medium mt-1 <?php echo ($b % 2 === 0) ? 'text-info' : 'text-warning'; ?>">
                    Status: <?php echo ($b % 2 === 0) ? 'Even Number' : 'Odd Number'; ?>
                </div>
            </div>
            
            <div class="stat px-6 py-3 border-l border-base-200 bg-base-200/50">
                <div class="stat-title text-xs font-bold uppercase tracking-wider text-base-content/70">Analysis: Larger Value</div>
                <div class="stat-value text-2xl mt-1 text-base-content">
                    <?php echo ($a > $b) ? $a : $b; ?>
                </div>
                <div class="stat-desc mt-1 font-semibold text-success">
                    <?php echo ($a > $b) ? "($a is strictly greater than $b)" : "($b is strictly greater than $a)"; ?>
                </div>
            </div>
        </div>

        <!-- Split Dashboard Views -->
        <div class="grid grid-cols-2 gap-6 flex-1 min-h-0">
            
            <!-- LEFT: Arithmetic Panel -->
            <div class="bg-base-200/50 rounded-2xl border border-base-200 p-5 flex flex-col h-full">
                <div class="flex justify-between items-end mb-4 shrink-0">
                    <h2 class="text-lg font-bold">Arithmetic Operations</h2>
                    <div class="badge badge-ghost text-xs">Variables: $a, $b</div>
                </div>
                
                <div class="overflow-hidden bg-base-100 rounded-xl border border-base-200 flex-1">
                    <table class="table table-sm table-zebra w-full h-full">
                        <thead class="bg-base-200/50 text-base-content/80">
                            <tr>
                                <th class="font-bold">Operation</th>
                                <th class="font-bold">Formula</th>
                                <th class="font-bold text-right">Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td class="font-medium">Addition</td><td class="font-mono text-xs opacity-75"><?php echo $a; ?> + <?php echo $b; ?></td><td class="text-right font-bold text-base-content"><?php echo $a + $b; ?></td></tr>
                            <tr><td class="font-medium">Subtraction</td><td class="font-mono text-xs opacity-75"><?php echo $a; ?> - <?php echo $b; ?></td><td class="text-right font-bold text-base-content"><?php echo $a - $b; ?></td></tr>
                            <tr><td class="font-medium">Multiplication</td><td class="font-mono text-xs opacity-75"><?php echo $a; ?> * <?php echo $b; ?></td><td class="text-right font-bold text-base-content"><?php echo $a * $b; ?></td></tr>
                            <tr><td class="font-medium">Division</td><td class="font-mono text-xs opacity-75"><?php echo $a; ?> / <?php echo $b; ?></td><td class="text-right font-bold text-base-content"><?php echo number_format($a / $b, 2); ?></td></tr>
                            <tr><td class="font-medium">Modulus</td><td class="font-mono text-xs opacity-75"><?php echo $a; ?> % <?php echo $b; ?></td><td class="text-right font-bold text-base-content"><?php echo $a % $b; ?></td></tr>
                        </tbody>
                    </table>
                </div>

                <!-- Increment Info Footer -->
                <?php
                $a_copy = $a; $b_copy = $b;
                $a_copy++; $b_copy--;
                ?>
                <div class="mt-4 pt-3 border-t border-base-300 flex justify-between items-center text-sm shrink-0">
                    <span class="font-semibold text-base-content/70">Post-Increment Test:</span>
                    <div class="flex gap-4 font-mono text-xs">
                        <span class="bg-base-100 px-2 py-1 rounded border border-base-300">$a++ ➔ <?php echo $a_copy; ?></span>
                        <span class="bg-base-100 px-2 py-1 rounded border border-base-300">$b-- ➔ <?php echo $b_copy; ?></span>
                    </div>
                </div>
            </div>

            <!-- RIGHT: Comparison Panel -->
            <div class="bg-base-200/50 rounded-2xl border border-base-200 p-5 flex flex-col h-full">
                <div class="flex justify-between items-end mb-4 shrink-0">
                    <h2 class="text-lg font-bold">Logical Comparisons</h2>
                    <div class="badge badge-ghost text-xs">Evaluations</div>
                </div>
                
                <div class="overflow-hidden bg-base-100 rounded-xl border border-base-200 flex-1">
                    <table class="table table-sm table-zebra w-full h-full">
                        <thead class="bg-base-200/50 text-base-content/80">
                            <tr>
                                <th class="font-bold w-1/4">Operator</th>
                                <th class="font-bold w-1/2">Meaning</th>
                                <th class="font-bold text-right w-1/4">Boolean</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $comparisons = [
                                ['==', 'Is exactly equal to',      $a == $b],
                                ['!=', 'Is not equal to',          $a != $b],
                                ['>',  'Strictly greater than',    $a > $b],
                                ['>=', 'Greater than or equal to', $a >= $b],
                                ['<',  'Strictly less than',       $a < $b],
                                ['<=', 'Less than or equal to',    $a <= $b],
                            ];
                            foreach ($comparisons as $row) {
                                $isTrue = $row[2];
                                $badgeClass = $isTrue ? 'badge-success text-success-content' : 'badge-error text-error-content opacity-80';
                                ?>
                                <tr>
                                    <td><code class="bg-base-200 px-2 py-1 rounded text-primary font-bold"><?php echo $row[0]; ?></code></td>
                                    <td class="text-xs text-base-content/80"><?php echo $row[1]; ?></td>
                                    <td class="text-right">
                                        <span class="badge badge-sm font-bold uppercase text-[10px] tracking-wider <?php echo $badgeClass; ?>">
                                            <?php echo var_export($isTrue, true); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Footer spacer to match height of the left card's footer -->
                <div class="mt-4 pt-3 border-t border-transparent flex justify-end items-center text-sm shrink-0 opacity-50">
                    <span class="text-xs italic text-base-content/60">Auto-calculated via PHP</span>
                </div>
            </div>

        </div> <!-- End Grid -->
    </div>
</div>

</body>
</html>